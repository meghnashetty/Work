export class Donation {
   email!: string;
   name!: string;
   amount!: number;
}