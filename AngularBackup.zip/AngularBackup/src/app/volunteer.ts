export class Volunteer {
   name!: string;
   email!: string;
   address!: string;
}