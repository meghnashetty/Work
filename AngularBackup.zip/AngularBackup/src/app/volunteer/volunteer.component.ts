import { Component, OnInit } from '@angular/core';
import { FeedbackServices } from './../feedback.service';
import { Volunteer } from './../volunteer'
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-volunteer',
  templateUrl: './volunteer.component.html',
  styleUrls: ['./volunteer.component.css']
})
export class VolunteerComponent implements OnInit {

  volunteer!: Volunteer;
  message!: string;

  constructor(private service: FeedbackServices, private sb : MatSnackBar) { }

  ngOnInit(): void {
    this.volunteer = new Volunteer();
  }

  becomeVolunteer() {
    this.service.becomeVolunteer(this.volunteer).subscribe(
      data => {this.volunteer = new Volunteer(); this.message = data; this.sb.open(data.toString(), "Dismiss")}, error => {console.log(error)}
    );
  }

}
