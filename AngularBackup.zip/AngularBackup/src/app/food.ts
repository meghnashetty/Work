export class Food {
   name!: string;
   email!: string;
   address!: string;
   fnop!: string;
}