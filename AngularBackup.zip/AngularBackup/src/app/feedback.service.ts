import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { Feedback } from './feedback';
import { Volunteer } from './volunteer';
import { User } from './user';
import { Food } from './food';
import { Clothes } from './clothes';
import { Medical } from './medical';
import { Travel } from './travel';
import { Donation } from './donation';
import { Admin } from './admin';

@Injectable({
   providedIn: 'root',
})

export class FeedbackServices {
   Admindisplay() {
     throw new Error('Method not implemented.');
   }
   private basePath= "http://localhost:8091/rest/feedback";

   constructor(private http: HttpClient) {}

   createFb(feedback: Feedback): Observable<any> {
      return this.http.post(`${this.basePath}/add`, feedback, {responseType: 'text'});
   }

   becomeVolunteer(volunteer: Volunteer): Observable<any> {
      return this.http.post(`${this.basePath}/volunteer`, volunteer, {responseType: 'text'});
   }

   regUser(user: User): Observable<any>  {
      return this.http.post(`${this.basePath}/reg`, user, {responseType: 'text'});
   }

   foodReq(food: Food): Observable<any> {
      return this.http.post(`${this.basePath}/food`, food, {responseType: 'text'});
   }

   clothReq(clothes: Clothes): Observable<any> {
      return this.http.post(`${this.basePath}/cloth`, clothes, {responseType: 'text'});
   }

   mediReq(medical: Medical): Observable<any> {
      return this.http.post(`${this.basePath}/medical`, medical, {responseType: 'text'});
   }

   travReq(travel: Travel): Observable<any> {
      return this.http.post(`${this.basePath}/travel`, travel, {responseType: 'text'});
   }

   donation(donation: Donation): Observable<any> {
      return this.http.post(`${this.basePath}/donation`, donation, {responseType: 'text'});
   }
   createAdminLogin(admin: Admin): Observable<any>{
      return this.http.post(`${this.basePath}/admin`, admin, {responseType: 'text'});

   }
   
   
}