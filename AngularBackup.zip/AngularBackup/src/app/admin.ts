export class Admin {
    name!: string;
    email!: string;
    
 }