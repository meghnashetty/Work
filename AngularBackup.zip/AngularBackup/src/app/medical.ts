export class Medical {
   email!: string;
   address!: string;
   medicine!: string;
}