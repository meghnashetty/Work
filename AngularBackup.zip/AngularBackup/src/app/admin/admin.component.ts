import { Component, OnInit } from '@angular/core';
import {MatSnackBar} from '@angular/material/snack-bar';
import { Food } from './../food';
import { Medical } from './../medical';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Feedback } from './../feedback';
import { AdminServices } from '../admin.service';
import { Donation } from '../donation';
import { Volunteer } from '../volunteer';
import { Clothes } from '../clothes';
import { Travel } from '../travel';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
// send this data to UI
food1!: Food[];
clothes!: Clothes[];
medicine1!: Medical[];
travel!: Travel[];
feedback1!:Feedback[];
donation!:Donation[];
volunteer!:Volunteer[];
message!: string;
// inject service layer
constructor(private service: AdminServices ,private http: HttpClient) { }

// on page load call this method
ngOnInit(): void {
  this.getAllStudents();
  this.getAllMedicine();
  this.getAllFeedback();
  this.getAllDonation();
  this.getAllVolunteer();
  this.getAllClothes();
  this.getAllTravel();
}
// fetch data from backend application using service
// tslint:disable-next-line: typedef
getAllStudents() {
  return this.service.getAllStudents()
  .subscribe(
    data => {
      this.food1 = data;
    }, error => {
      console.log(error);
    }
  );
}
getAllMedicine() {
  return this.service.getAllMedicine()
  .subscribe(
    data => {
      this.medicine1 = data;
    }, error => {
      console.log(error);
    }
  );
}

getAllTravel() {
  return this.service.getAllTravel()
  .subscribe(
    data => {
      this.travel = data;
    }, error => {
      console.log(error);
    }
  );
}
getAllFeedback() {
  return this.service.getAllFeedback()
  .subscribe(
    data => {
      this.feedback1 = data;
    }, error => {
      console.log(error);
    }
  );
}
getAllDonation() {
  return this.service.getAllDonation()
  .subscribe(
    data => {
      this.donation = data;
    }, error => {
      console.log(error);
    }
  );
}
getAllVolunteer() {
  return this.service.getAllVolunteer()
  .subscribe(
    data => {
      this.volunteer = data;
    }, error => {
      console.log(error);
    }
  );
}
getAllClothes() {
  return this.service.getAllClothes()
  .subscribe(
    data => {
      this.clothes = data;
    }, error => {
      console.log(error);
    }
  );
}
// tslint:disable-next-line: typedef


}