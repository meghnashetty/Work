package com.sreesha.in;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngSngWorking {
	public static void main(String[] args) {
		SpringApplication.run(AngSngWorking.class, args);
	}

}
