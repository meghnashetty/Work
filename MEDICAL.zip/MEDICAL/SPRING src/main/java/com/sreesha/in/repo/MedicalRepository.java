package com.sreesha.in.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sreesha.in.model.Medical;

public interface MedicalRepository extends JpaRepository<Medical, String> {

	void deleteByEmail(String email);

}
