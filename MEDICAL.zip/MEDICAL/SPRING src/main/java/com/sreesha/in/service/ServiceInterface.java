package com.sreesha.in.service;

import java.util.List;

import com.sreesha.in.model.Medical;

public interface ServiceInterface {
	
	

	public Integer saveMedical(Medical medical);

	public List<Medical> getAllMedical();

	public void deleteMedical(String email);


	
	
}
