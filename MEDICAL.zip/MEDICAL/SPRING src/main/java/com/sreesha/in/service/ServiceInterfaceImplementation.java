package com.sreesha.in.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.sreesha.in.model.Medical;
import com.sreesha.in.repo.MedicalRepository;



@Service
public class ServiceInterfaceImplementation implements ServiceInterface {
	
	@Autowired
	private MedicalRepository repo;

	

	public void deleteMedical(String email) {
		repo.deleteByEmail(email);
	}

	public Integer saveMedical(Medical medical) {
		medical = repo.save(medical);
		return medical.getId();
	}

	public List<Medical> getAllMedical() {
		return repo.findAll();
	}

	
	
	


	

	
	}


