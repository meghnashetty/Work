import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Medical } from './medical';


@Injectable({
  providedIn: 'root'
})
export class MedicalService {
    
  private basePath = 'http://localhost:8090/rest/medical';

  constructor(private http: HttpClient) { 
      
  }


  getAllMedical(): Observable<Medical[]> {
    return this.http.get<Medical[]>(`${this.basePath}/view`);
  }

  

  createMedical(medical: Medical): Observable<any> {
    return this.http.post(`${this.basePath}/add`, medical, {responseType: 'text'});
  }

}