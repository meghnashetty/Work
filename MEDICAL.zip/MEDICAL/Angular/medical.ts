export class Medical {
   
    public email!: string;
    public address!:string;
    public medicine!: string;
}