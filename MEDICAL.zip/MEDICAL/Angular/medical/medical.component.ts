import { Component, OnInit } from '@angular/core';
import { MedicalService } from './../medical.service';
import { Medical } from '../medical';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-medical',
  templateUrl: './medical.component.html',
  styleUrls: ['./medical.component.css']
})
export class MedicalComponent implements OnInit {
  // form backing object
  medical!:Medical;
  // message to ui
  message!: string;
  // inject service class
  constructor(private service: MedicalService, private http: HttpClientModule) { }
  ngOnInit(): void {
    // when page is loaded clear form data
    this.medical = new Medical();
    
  }
  
  // tslint:disable-next-line: typedef
  createMedical() {
    this.service.createMedical(this.medical)
    .subscribe(data => {
      this.message = data; // read message
      this.medical = new Medical(); 
      console.log(this.message);// clear form
    }, error => {
      console.log(error);
    });
  }
}

