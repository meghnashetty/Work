package entity;

public class Employee {

	private int id;
	private String firstName;
	private String bankname;
	private String accno;
	private String phone;
	private String address;

	public Employee() {
	}

	public Employee(int id, String firstName, String bankname, String accno, String phone, String address) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.bankname = bankname;
		this.accno = accno;
		this.phone = phone;
		this.address = address;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getAccno() {
		return accno;
	}

	public void setAccno(String accno) {
		this.accno = accno;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", firstName=" + firstName + ", bankname=" + bankname + ", accno=" + accno
				+ ", phone=" + phone + ", address=" + address + "]";
	}
	

	
}
