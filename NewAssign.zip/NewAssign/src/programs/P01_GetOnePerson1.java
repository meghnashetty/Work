package programs;
import java.util.Scanner;
import org.hibernate.Session;


import entity.Employee;
import util.HibernateUtil;

public class P01_GetOnePerson1 {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSession();
		Scanner in=new Scanner(System.in);
		System.out.println("Enter Bank Employee ID");
		int id= in.nextInt(); //reads string.
		//int id = 101;
		Employee p1 = (Employee) session.get(Employee.class, id);

		if (p1 == null) {
			System.out.println("No data found!");
		} else {
			System.out.println("Name  = " + p1.getFirstName());
			System.out.println("Bankname = " + p1.getBankname());
			System.out.println("accno = " + p1.getAccno());
			System.out.println("Phone = " + p1.getPhone());
			System.out.println("Address = " + p1.getAddress());
		}

	}

}
