package programs;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import entity.Employee;
import util.HibernateUtil;
import util.KeyboardUtil;

public class P02_AddEmpDetails {

	public static void main(String[] args) {

		int id;
		String fname, bankname,accno, phone, address;

		id = KeyboardUtil.getInt("Enter id: ");
		fname = KeyboardUtil.getString("Enter firstname: ");
		bankname = KeyboardUtil.getString("Enter bankname: ");
		accno = KeyboardUtil.getString("Enter accno: ");
		phone = KeyboardUtil.getString("Enter phone: ");
		address = KeyboardUtil.getString("Enter address: ");

		Employee p1 = new Employee (id, fname, bankname,accno, phone, address);
		
		
		Session session = HibernateUtil.getSession();
		Transaction tx = session.beginTransaction();
		try {
			session.save(p1);
			tx.commit();
			System.out.println("Data saved to db.");
		} catch (HibernateException e) {
			tx.rollback();
			System.out.println("There was an error while trying to save data.");
			System.out.println(e.getMessage());
		}
		
		session.close();
		

	}
}









