package programs;

import org.hibernate.Session;

import entity.Employee;
import util.HibernateUtil;
import util.KeyboardUtil;

public class P04_UpdateEmployeeData {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSession();
		int id = KeyboardUtil.getInt("Enter id: ");
		session.beginTransaction();
		Employee p1 = (Employee) session.get(Employee.class, id);

		if (p1 == null) {
			System.out.println("No data found!");
		} else {
			String input;

			input = KeyboardUtil.getString("First name : (" + p1.getFirstName() + ") ");
			if (!input.equals("")) {
				p1.setFirstName(input);
			}

			input = KeyboardUtil.getString("Bankname : (" + p1.getBankname() + ") ");
			if (!input.equals("")) {
				p1.setBankname(input);
			}
			input = KeyboardUtil.getString("Accno : (" + p1.getAccno() + ") ");
			if (!input.equals("")) {
				p1.setAccno(input);
			}

			input = KeyboardUtil.getString("Phone : (" + p1.getPhone() + ") ");
			if (!input.equals("")) {
				p1.setPhone(input);
			}

			input = KeyboardUtil.getString("Address : (" + p1.getAddress() + ") ");
			if (!input.equals("")) {
				p1.setAddress(input);
			}

			session.getTransaction().commit();
			System.out.println("Data updated back to the db.");

		}

	}
}
