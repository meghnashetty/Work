package com.sreesha.project.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sreesha.project.model.Volunteer;

public interface VolunteerRepo extends JpaRepository<Volunteer, Integer> {

}
