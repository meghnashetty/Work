package com.sreesha.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.project.model.Volunteer;
import com.sreesha.project.repo.VolunteerRepo;

@Service
public class VolunteerImplementation implements VolunteerServiceInterface {

	@Autowired
	private VolunteerRepo vr;
	
	public Integer saveVolunteer(Volunteer volunteer) {
		volunteer = vr.save(volunteer);
		return volunteer.getId();
	}
	public List<Volunteer> getAllVolunteer() {
		return vr.findAll();
	}
	
}
