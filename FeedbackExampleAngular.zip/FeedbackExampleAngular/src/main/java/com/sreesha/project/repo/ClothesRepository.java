package com.sreesha.project.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sreesha.project.model.Clothes;

public interface ClothesRepository extends JpaRepository<Clothes, Integer> {

}
