package com.sreesha.project.service;
import java.util.*;

import com.sreesha.project.model.FeedbackModel;

public interface FeedbackServiceInterface {

	
	List<FeedbackModel> getAllFeedback();
	public Integer saveFeedback(FeedbackModel feedback);
}
