package com.sreesha.project.service;
import java.util.*;

import com.sreesha.project.model.Medical;

public interface MedicalServiceInterface {

	public Integer saveMedical(Medical medical);
	List<Medical> getAllMedicine();
}
