package com.sreesha.project.controller;

import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sreesha.project.model.Clothes;
import com.sreesha.project.model.Donation;
import com.sreesha.project.model.FeedbackModel;
import com.sreesha.project.model.Food;
import com.sreesha.project.model.Medical;
import com.sreesha.project.model.Travel;
import com.sreesha.project.model.User;
import com.sreesha.project.model.Volunteer;
import com.sreesha.project.service.ClothesServiceInterface;
import com.sreesha.project.service.DonationServiceInterface;
import com.sreesha.project.service.FeedbackServiceInterface;
import com.sreesha.project.service.FoodServiceInterface;
import com.sreesha.project.service.MedicalServiceInterface;
import com.sreesha.project.service.TravelServiceInterface;
import com.sreesha.project.service.UserServiceInterface;
import com.sreesha.project.service.VolunteerServiceInterface;



@RestController
@RequestMapping("/rest/feedback")
@CrossOrigin(origins = "http://localhost:4200")
public class FeedbackController {
	
	private Logger log = LoggerFactory.getLogger(FeedbackController.class);
	
	@Autowired
	private FeedbackServiceInterface fsi;
	
	@Autowired
	private VolunteerServiceInterface vsi;
	
	@Autowired
	private UserServiceInterface usi;
	
	@Autowired
	private FoodServiceInterface foodsi;
	
	@Autowired
	private ClothesServiceInterface csi;
	
	@Autowired
	private MedicalServiceInterface msi;
	
	@Autowired
	private TravelServiceInterface tsi;
	
	@Autowired
	private DonationServiceInterface dsi;
	
	@PostMapping("/add")
	public ResponseEntity<String> saveFeedback(@RequestBody FeedbackModel feedback) {
		try {
			Integer id = fsi.saveFeedback(feedback);
			String msg = "Feedback with id "+id+" created successfully";
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			return new ResponseEntity<String>("Unable to create feedback", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/volunteer")
	public ResponseEntity<String> saveVolunteer(@RequestBody Volunteer volunteer) {
		try {
			Integer id = vsi.saveVolunteer(volunteer);
			String msg = "Thank you for Signing up as a Volunteer. Your volunteer account has been created with id "+id+".";
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<String>("Unable to create volunteer", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/reg")
	public ResponseEntity<String> saveUser(@RequestBody User user) {
		try {
			String mail = usi.saveUser(user);
			String msg = "Registration Successful with the mail address "+mail+".";
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<String>("Unable to create", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/food")
	public ResponseEntity<String> saveFood(@RequestBody Food food) {
		try {
			Integer id = foodsi.saveFood(food);
			String msg = "Request for food submitted sucessfully! Your request id is "+id;
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			return new ResponseEntity<String>("Unable to create!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@PostMapping("/cloth")
	public ResponseEntity<String> saveclothes(@RequestBody Clothes clothes){
		try {
			int id = csi.saveClothes(clothes);
			String msg = "Request for clothes submitted sucessfully! Your request id is "+id;
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Unable to create!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@PostMapping("/medical")
	public ResponseEntity<String> saveMedical(@RequestBody Medical medical) {
		try {
			Integer id = msi.saveMedical(medical);
			String msg = "Request for medicine submitted sucessfully! Your request id is "+id;
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Unable to create!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@PostMapping("/travel")
	public ResponseEntity<String> saveTravel(@RequestBody Travel travel) {
		try {
			String email = tsi.saveTravel(travel);
			String msg = "Request for travel submitted sucessfully reference to mail: "+email;
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Unable to create!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	@PostMapping("/donation")
	public ResponseEntity<String> saveDonation(@RequestBody Donation donation) {
		try {
			Integer id = dsi.saveDonation(donation);
			String msg = "Thank you for your contribution! Your reference id is "+id;
			return new ResponseEntity<String>(msg, HttpStatus.CREATED);
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Unable to create!", HttpStatus.INTERNAL_SERVER_ERROR);
		}	
	}
	@GetMapping("/getFood")
	public ResponseEntity<?> getAllFood() {
		log.info("Entered into method to fetch Students data");
		ResponseEntity<?> resp = null ;
		try {

			log.info("About to call fetch student service");
			List<Food> list = foodsi.getAllFood();
			if(list!=null && !list.isEmpty()) {
				log.info("Data is not empty=>"+list.size());
		
			
				resp = new ResponseEntity<List<Food>>(list, HttpStatus.OK);
			} else {
				log.info("No Student exist: size "+list.size());

				//resp = new ResponseEntity<>(HttpStatus.NO_CONTENT);
				resp = new ResponseEntity<String>(
						"No Students Found",
						HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Unable to fetch students : problem is :"+e.getMessage());

			resp =  new ResponseEntity<String>(
					"Unable to Fetch Students", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		log.info("About to Exist fetch all method with Response");
		return resp;
	}
	
	@GetMapping("/getMedical")
	public ResponseEntity<?> getAllMedicine() {
		log.info("Entered into method to fetch data");
		ResponseEntity<?> resp = null ;
		try {

			log.info("About to call fetch medical service");
			List<Medical> list = msi.getAllMedicine();
			if(list!=null && !list.isEmpty()) {
				log.info("Data is not empty=>"+list.size());
		
			
				resp = new ResponseEntity<List<Medical>>(list, HttpStatus.OK);
			} else {
				log.info("No help exist: size "+list.size());

				//resp = new ResponseEntity<>(HttpStatus.NO_CONTENT);
				resp = new ResponseEntity<String>(
						"No Help Found",
						HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Unable to fetch help : problem is :"+e.getMessage());

			resp =  new ResponseEntity<String>(
					"Unable to Fetch help", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		log.info("About to Exist fetch all method with Response");
		return resp;
	}
	
	@GetMapping("/getClothes")
	public ResponseEntity<?> getAllClothes() {
		log.info("Entered into method to fetch data");
		ResponseEntity<?> resp = null ;
		try {

			log.info("About to call fetch clothes service");
			List<Clothes> list = csi.getAllClothes();
			if(list!=null && !list.isEmpty()) {
				log.info("Data is not empty=>"+list.size());
		
			
				resp = new ResponseEntity<List<Clothes>>(list, HttpStatus.OK);
			} else {
				log.info("No help exist: size "+list.size());

				//resp = new ResponseEntity<>(HttpStatus.NO_CONTENT);
				resp = new ResponseEntity<String>(
						"No Help Found",
						HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Unable to fetch help : problem is :"+e.getMessage());

			resp =  new ResponseEntity<String>(
					"Unable to Fetch help", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		log.info("About to Exist fetch all method with Response");
		return resp;
	}
	
	@GetMapping("/getTravel")
	public ResponseEntity<?> getAllTravel() {
		log.info("Entered into method to fetch data");
		ResponseEntity<?> resp = null ;
		try {

			log.info("About to call fetch Travel service");
			List<Travel> list = tsi.getAllTravel();
			if(list!=null && !list.isEmpty()) {
				log.info("Data is not empty=>"+list.size());
		
			
				resp = new ResponseEntity<List<Travel>>(list, HttpStatus.OK);
			} else {
				log.info("No help exist: size "+list.size());

				//resp = new ResponseEntity<>(HttpStatus.NO_CONTENT);
				resp = new ResponseEntity<String>(
						"No Help Found",
						HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Unable to fetch help : problem is :"+e.getMessage());

			resp =  new ResponseEntity<String>(
					"Unable to Fetch help", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		log.info("About to Exist fetch all method with Response");
		return resp;
	}
	
	
	@GetMapping("/getFeedback")
	public ResponseEntity<?> getAllFeedback() {
		log.info("Entered into method to fetch data");
		ResponseEntity<?> resp = null ;
		try {

			log.info("About to call fetch feedback service");
			List<FeedbackModel> list = fsi.getAllFeedback();
			if(list!=null && !list.isEmpty()) {
				log.info("Data is not empty=>"+list.size());
		
			
				resp = new ResponseEntity<List<FeedbackModel>>(list, HttpStatus.OK);
			} else {
				log.info("No help exist: size "+list.size());

				//resp = new ResponseEntity<>(HttpStatus.NO_CONTENT);
				resp = new ResponseEntity<String>(
						"No Help Found",
						HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Unable to fetch help : problem is :"+e.getMessage());

			resp =  new ResponseEntity<String>(
					"Unable to Fetch help", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		log.info("About to Exist fetch all method with Response");
		return resp;
	}
	
	@GetMapping("/getDonation")
	public ResponseEntity<?> getAllDonation() {
		log.info("Entered into method to fetch data");
		ResponseEntity<?> resp = null ;
		try {

			log.info("About to call fetch donation service");
			List<Donation> list = dsi.getAllDonation();
			if(list!=null && !list.isEmpty()) {
				log.info("Data is not empty=>"+list.size());
		
			
				resp = new ResponseEntity<List<Donation>>(list, HttpStatus.OK);
			} else {
				log.info("No help exist: size "+list.size());

				//resp = new ResponseEntity<>(HttpStatus.NO_CONTENT);
				resp = new ResponseEntity<String>(
						"No Help Found",
						HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Unable to fetch help : problem is :"+e.getMessage());

			resp =  new ResponseEntity<String>(
					"Unable to Fetch help", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		log.info("About to Exist fetch all method with Response");
		return resp;
	}
	
	@GetMapping("/getVolunteer")
	public ResponseEntity<?> getAllVolunteer() {
		log.info("Entered into method to fetch data");
		ResponseEntity<?> resp = null ;
		try {

			log.info("About to call fetch donation service");
			List<Volunteer> list = vsi.getAllVolunteer();
			if(list!=null && !list.isEmpty()) {
				log.info("Data is not empty=>"+list.size());
		
			
				resp = new ResponseEntity<List<Volunteer>>(list, HttpStatus.OK);
			} else {
				log.info("No help exist: size "+list.size());

				//resp = new ResponseEntity<>(HttpStatus.NO_CONTENT);
				resp = new ResponseEntity<String>(
						"No Help Found",
						HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Unable to fetch help : problem is :"+e.getMessage());

			resp =  new ResponseEntity<String>(
					"Unable to Fetch help", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		log.info("About to Exist fetch all method with Response");
		return resp;
	}
	
	
}
