package com.sreesha.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.project.model.User;
import com.sreesha.project.repo.UserRepo;

@Service
public class UserImplementation implements UserServiceInterface {
	
	@Autowired
	private UserRepo ur;

	public String saveUser(User user) {
		// TODO Auto-generated method stub
		user = ur.save(user);
		return user.getEmail();
	}

}
